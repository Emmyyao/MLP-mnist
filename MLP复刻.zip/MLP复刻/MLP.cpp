//这是一个对MLP基础神经网络模型的cpp复刻，数据集为mnist的10000个数据样本。
//全篇代码分为了九个子任务，便于阅读与理解
//2026.1.30-2026.2.3 yyx

/*=============1基础头文件与全局变量定义===============
引入必要头文件（bits/stdc++.h/fstream/io.h）
定义层数、学习率、训练轮数等全局变量
声明神经网络核心容器（权重w、偏置b、激活输出a等）*/

#include<bits/stdc++.h>   // 包含常用STL头文件
#include<fstream>         // 文件读写
#include<io.h>            // 文件存在性检查（Windows）
#include<iomanip>         // 用于setprecision
#define MAX_M 8           // 最大层数限制为8层
using namespace std;

int m, epoch;              // m: 层数（含输入/输出层）, epoch: 训练轮数
double lr;                 // lr: 学习率
int n[MAX_M] = {0};        // n[i]: 第i层的节点个数

vector<vector<vector<float>>> w;
vector<vector<float>> b,z,a,T;

/*==============2初始化神经网络容器=================
编写initialization()函数
根据层数和节点数，为所有vector容器分配空间
区分输入层（仅需激活输出a）和隐藏 / 输出层（需权重、偏置、梯度）*/

void initialization(){
    w.resize(m);
    b.resize(m);
    z.resize(m);
    a.resize(m);
    T.resize(m);
    
    for(int i=1;i<m;i++){ //从第一层开始，因为第零层是输入层
        w[i].resize(n[i-1]);
        for(int j=0;j<n[i-1];j++){
            w[i][j].resize(n[i]);
        }
        b[i].resize(n[i]);
        z[i].resize(n[i]);
        T[i].resize(n[i]);
    }
    for(int i=0;i<m;i++){ // 输入层（0 层）有a[0]（输入数据）
        a[i].resize(n[i]);
    }
}


/*=============3实现 CSV 文件行读取函数================
编写read_csv_line()函数
逐字符解析 CSV 行数据，按逗号分割并拼接为整数数组
完成 “字符→数字” 的转换逻辑*/

vector<int> read_csv_line(string line){
    vector<int> pure_number;
    stringstream ss(line);
    string token;
    while(getline(ss,token,',')){
        pure_number.push_back(stoi(token));
    }
    return pure_number;
}

/*=====================4实现前向传播函数=========================
编写Forward_Propagation()函数
计算隐藏层的线性输出z和 sigmoid 激活输出a
对输出层单独实现 softmax 激活（含数值稳定处理）
返回输出层最大值对应的预测数字*/

int Forward_Propagation(){
    for(int i=1;i<m;i++){
        for(int j=0;j<n[i];j++){
            z[i][j]=b[i][j];
            for(int k=0;k<n[i-1];k++){
                z[i][j]+=w[i][k][j]*a[i-1][k];
            }
            if(i!=m-1){//如果不是最后一层就用sigmoid折算。最后一层到时候单独用softmax算（注意因为第一层是0层，所以最后一层是m-1层)
                a[i][j]=1.0/(1+exp(-z[i][j]));
            }
        }
    }

    //现在来单独激活最后一层
    float softmax_sum=0 , softmax_max=z[m-1][0];
    //找最大值，后续减去最大值可以防止指数运算后数据过大，计算爆表
    for(int i=0;i<n[m-1];i++){
        softmax_max=(z[m-1][i]>softmax_max)?z[m-1][i]:softmax_max;
    }
    //算softmax函数的分母
    for(int i=0;i<n[m-1];i++){
        softmax_sum+=exp(z[m-1][i]-softmax_max);
    }
    //执行softmax运算
    for(int i=0;i<n[m-1];i++){
        a[m-1][i]=exp(z[m-1][i]-softmax_max)/softmax_sum;
    }

    int my_solution=0;
    float max=0.0;
    for(int i=0;i<n[m-1];i++){
        if (a[m-1][i]>max){
            my_solution=i;
            max=a[m-1][i];
        }
    }
    return my_solution;
}

/*=================5实现测试函数（验证准确率）=======================
编写test()函数
读取测试集mnist_test.csv，逐行进行前向传播
统计预测正确数，计算并返回测试集准确率
主函数 - 初始化交互（新建 / 加载模型）*/

float test(){
    ifstream test_file("mnist_test.csv"); // 替换重定向，直接创建文件流
    if (!test_file.is_open()) { // 增加文件打开检查
        cerr << "错误：无法打开测试集文件 mnist_test.csv" << endl;
        return 0.0;
    }
    
    int correct=0;
    float acc=0;

    for(int data=0;data<10000;data++){
        for(int i=1;i<m;i++){
            fill(z[i].begin(),z[i].end(),0);
            fill(a[i].begin(),a[i].end(),0);
            fill(T[i].begin(), T[i].end(), 0);
        }
        int ans=0, my_ans=0;
        string line;
        getline(test_file, line); // 使用文件流读取行
        if (line.empty()) break; // 防止文件提前结束
        
        vector<int> get_line=read_csv_line(line);
        ans=get_line[0];

        for(int i=1;i<get_line.size();i++){
            a[0][i-1]=get_line[i]/255.0;
        }
        my_ans=Forward_Propagation();

        if(ans==my_ans)++correct;
    }
    test_file.close(); // 关闭文件流
    acc=correct/10000.0;
    return acc;
}

//主函数里面有剩下几个任务
int main(){
/*=================6实现用户交互逻辑：选择 “新建模型” 或 “加载已有模型”===============
新建模型：设置层数、学习率、训练轮数、隐藏层节点数
加载模型：检查参数文件data.dat，读取并初始化网络参数*/

    cout << "本程序用于训练针对mnist数据集手写数字识别的人工神经网络" << endl;

    // 第一步：选择新建模型或加载模型
    cout << "你希望: 1. 重新构建并训练一个神经网络 2. 用已有参数继续训练" << endl;
    int choice=0;
    while(1){
        if (choice!=1&&choice!=2){
            cout << "请输入1或2" << endl;
            cin >> choice;
        }
        else break;
    }
    
    if (choice==1){
        // 确定层数（3-8层）
        while(1){
            cout << "神经网络层数（含输入输出层）：" << endl;
            cin >> m;
            if(m <= 2){
                cout << "至少3层" << endl;
            } else if(m >= 9){
                cout << "最多8层" << endl;
            } else {
                break;
            }
        }
        // 设置学习率和训练轮数
        cout << "设置神经网络学习率：" << endl;
        cin >> lr;
        cout << "设置训练轮数(epoch):" << endl;
        cin >> epoch;

        n[0]=28*28;
        n[m-1]=10;
        cout << "已设定好第0层(输入层)节点数为784 ; 第" << m-1 << "层(输出层)节点数为10"<< endl;
        for(int i=1;i<m-1;i++){
            cout << "接下来请设置第"<< i <<"层节点数："<< endl;
            cin >> n[i];
        }
    }

    if (choice==2){
        // 读取参数文件：替换freopen为ifstream
        ifstream model_file("data.dat");
        if (!model_file.is_open()) {
            cerr << "错误：无法打开模型文件 data.dat" << endl;
            return -1;
        }
        
        model_file >> m; // 从文件流读取层数
        for(int i=0; i<m; i++){
            model_file >> n[i]; // 读取各层节点数
        }

        initialization();

        for(int i=1;i<m;i++){
            for(int j=0;j<n[i-1];j++){
                for(int k=0;k<n[i];k++){
                    model_file >> w[i][j][k]; // 读取权重
                }
            }
        }
        for(int i=1;i<m;i++){
            for(int j=0;j<n[i];j++){
                model_file >> b[i][j]; // 读取偏置
            }
        }
        model_file.close(); // 关闭模型文件

        // 显示加载信息
        cout << "参数加载完毕。该神经网络有" << m << "层，各层分别有";
        for(int i=0; i<m; i++){
            cout << n[i] << " ";
        }
        cout << "个节点。" << endl;

        // 重新设置学习率和训练轮数
        cout << "设置你希望的神经网络学习率：";
        cin >> lr;
        cout << "设置你希望的训练轮数(epoch):";
        cin >> epoch;
    }
    
    cout << endl << "===================训练开始===================" << endl << endl;

/*====================7主函数 - 初始化模型参数（随机生成）===========================
为新建模型随机生成初始权重（范围(-1,1)）和偏置（范围(0,1)）
设置随机数种子，保证每次运行参数不同
初始化 one-hot 标签数组y和损失数组L*/

// 定义损失函数和标签相关数组
    vector<int> y(n[m-1],0);       // y[i]: 输出层i节点的预期输出（one-hot）
    vector<float> L(n[m-1],0);     // L[i]: 输出层i节点的损失

    // 若新建模型：随机初始化参数
    if(choice == 1){
        initialization(); // 初始化容器

        // 随机生成权重和偏置
        cout << "开始生成随机参数..." << endl;
        srand((unsigned)time(NULL)); // 设置随机数种子
        for(int i=1; i<m; i++){
            // 权重：范围(-1,1)
            for(int j=0; j<n[i-1]; j++){
                for(int k=0; k<n[i]; k++){
                    // 随机符号 * 0-1的小数
                    w[i][j][k] = pow((-1), rand()%2) * (rand()%10000)*1.0/10000;
                }
            }
            // 偏置：范围(0,1)
            for(int j=0; j<n[i]; j++){
                b[i][j] = (rand()%100)*1.0/100;
            }
        }
    }

/*====================8主函数 - 训练核心逻辑（前向 + 反向传播）=======================
编写训练轮数循环（epoch轮）
单条数据训练流程：清空容器→读取数据→前向传播→计算损失和梯度→反向传播→参数更新
实现交叉熵损失计算和梯度下降参数更新公式*/

// 训练主体循环
    cout << "开始训练..." << endl;
    for(int ep=0;ep<epoch;ep++){
        cout << "第" << ep << "轮训练" << endl;
        int yes=0; // 本轮训练集答对的个数
        
        // 替换freopen：用ifstream读取训练集
        ifstream train_file("mnist_train.csv");
        if (!train_file.is_open()) {
            cerr << "错误：无法打开训练集文件 mnist_train.csv" << endl;
            return -1;
        }

        for(int data=0; data<60000; data++){ // 遍历60000条训练数据
            if(data%10000 == 0){
                cout << "====="; // 进度条（每10000条输出一个标记）
            }

            // 清空本轮的z、a、T、y、L（避免上一轮数据干扰）
            for(int i=1; i<m; i++){
                fill(z[i].begin(), z[i].end(), 0);
                fill(a[i].begin(), a[i].end(), 0);
                fill(T[i].begin(), T[i].end(), 0);
            }
            fill(y.begin(), y.end(), 0);
            fill(L.begin(), L.end(), 0);

            string line;
            getline(train_file, line); // 从训练文件流读取行
            if (line.empty()) break; // 防止文件提前结束
            
            vector<int> get_line= read_csv_line(line);
            int solution = get_line[0];
            y[solution]=1;
            int my_solution;

            //输入层归一化
            for(int i=0;i<get_line.size()-1;i++){
                a[0][i]=get_line[i+1]/255.0;
            }

            //前向传播求结果
            my_solution = Forward_Propagation();
            if(my_solution==solution) ++yes;

            //计算交叉熵损失
            float L_sum=0;
            for (int i=0;i<n[m-1];i++){
                L[i]= - y[i] * log(a[m-1][i]);
                L_sum += L[i];
                // 2. 计算输出层梯度T[m-1][i]（核心！）(总损失对输出层每个节点的z的偏导)
                // 公式：T[m-1][i] = a[m-1][i] - y[i]（softmax+交叉熵的简化结果）
                T[m-1][i] = a[m-1][i] - y[i];
            }
            // 步骤6：反向传播计算隐藏层梯度（加在步骤5后）
            // 从倒数第二层（m-2）往第一层（1）算（反向！）
            for(int i=m-2; i>=1; i--){
                for(int j=0; j<n[i]; j++){ // 第i层的第j个节点
                    T[i][j] = 0;
                    // 第一步：累加下一层梯度 * 对应权重
                    for(int k=0; k<n[i+1]; k++){
                        T[i][j] += T[i+1][k] * w[i+1][j][k];
                    }
                    // 第二步：乘以sigmoid导数
                    T[i][j] *= a[i][j] * (1 - a[i][j]);
                }
            }

            // 步骤7：更新权重和偏置（加在步骤6后）
            for(int i=m-1; i>=1; i--){
                // 1. 更新权重w[i][j][k]
                for(int j=0; j<n[i-1]; j++){ // 上一层的j节点
                    for(int k=0; k<n[i]; k++){ // 当前层的k节点
                        w[i][j][k] -= lr * T[i][k] * a[i-1][j];
                    }
                }
                // 2. 更新偏置b[i][j]
                for(int j=0; j<n[i]; j++){
                    b[i][j] -= lr * T[i][j];
                }
            }
        }

        train_file.close(); // 关闭训练文件流
        // 输出本轮准确率
        cout << endl << "本轮训练集正确率：" << yes/60000.0 << endl;
        cout << "本轮测试集正确率：" << test() << endl;
    }

/*==========================9主函数 - 保存模型参数===================================
训练完成后，将层数、节点数、权重、偏置写入data.dat
按固定格式保存参数，保证后续可正确加载
恢复标准输入输出，避免程序异常*/
    // 保存模型参数到data.dat：替换freopen为ofstream
    cout << endl << "保存参数..." << endl;
    ofstream save_file("data.dat");
    if (!save_file.is_open()) {
        cerr << "错误：无法打开保存模型文件 data.dat" << endl;
        return -1;
    }
    
    save_file << m << endl; // 写入层数
    for(int i=0; i<m; i++){ // 写入各层节点数
        save_file << n[i] << " ";
    }
    save_file << endl;
    save_file << fixed << setprecision(5); // 保留5位小数输出

    // 保存权重w
    for(int i=1; i<m; i++){
        for(int j=0; j<n[i-1]; j++){
            for(int k=0; k<n[i]; k++){
                save_file << w[i][j][k] << " ";
            }
        }
        save_file << endl;
    }
    // 保存偏置b
    for(int i=1; i<m; i++){
        for(int j=0; j<n[i]; j++){
            save_file << b[i][j] << " ";
        }
        save_file << endl;
    }

    save_file.close(); // 关闭保存文件流
    system("pause"); // 暂停程序，查看输出
    return 0;
}