#include<iostream>
#include<vector>
using namespace std;

int main(){
    //这是一个2+3+1的三层网络，接下来为存储所有权重编写一个结构
    //先定义一个空容器w，准备装所有层的每一个权重
    vector<vector<vector<float>>>w;

    //开始定义0->1层的权重
    vector<vector<float>>layer0_1;//也是先开辟容器
    vector<float>neuron00_layer1{0.2f,0.3f,0.4f};
    vector<float>neuron01_layer1{0.3f,0.4f,0.5f};

    layer0_1.push_back(neuron00_layer1);//把两个一维数组收编进二维数组
    layer0_1.push_back(neuron01_layer1);

    //开始定义1->2层的权重，同理
    vector<vector<float>>layer1_2;//也是先开辟容器
    vector<float>neuron10_layer2{0.2f};
    vector<float>neuron11_layer2{0.3f};
    vector<float>neuron12_layer2{0.7f};

    layer1_2.push_back(neuron10_layer2);
    layer1_2.push_back(neuron11_layer2);
    layer1_2.push_back(neuron12_layer2);

    //把两层的权重统一收编进w
    w.push_back(layer0_1);
    w.push_back(layer1_2);

    // ========== 访问示例 ==========
    // 第0层节点0 → 第1层节点2的权重
    cout<<w[0][0][2]<<endl;


}